FIXBYTE PUBLIC FOLDER - FIXED

Files included:
- index.html
- services.html
- pricing.html
- portfolio.html
- contact.html
- login.html
- signup.html
- dashboard.html
- admin-login.html
- admin.html
- css/style.css
- js/app.js

Changes:
1. Removed progressive-app references from public pages.
2. admin.html uses ASCII-safe text to prevent broken currency/symbol encoding.
3. Rebuilt pages that were empty in the uploaded archive.
4. Restored dashboard.html because it was missing from the uploaded archive.
