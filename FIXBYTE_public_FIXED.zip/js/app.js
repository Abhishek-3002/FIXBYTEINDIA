
(function(){
  const toggle=document.getElementById("navToggle");
  const links=document.getElementById("navLinks");
  if(toggle && links){toggle.addEventListener("click",()=>links.classList.toggle("open"));}
  document.querySelectorAll("[data-year]").forEach(el=>el.textContent=new Date().getFullYear());
})();
